package com.demo.pushtotalk;

public interface Common{
    final String TCP_INTENT_ACTION_CMD = "android.intent.action.tcp.cmd";
}

